package com.example.paypark.views

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import com.example.paypark.R
import kotlinx.android.synthetic.main.activity_sign_in.*

class SignInActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var tvCreateAccount: TextView
    val TAG: String = this@SignInActivity.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        tvCreateAccount = findViewById(R.id.tvCreateAccount)
        tvCreateAccount.setOnClickListener(this)

        btnSignIn.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        Log.d(TAG, "Button was clicked")
        if (v != null) {
            when (v.id) {
                tvCreateAccount.id -> {
                    //go to SignUpActivity
                    goToSignUp()
                }
                btnSignIn.id -> {
                    this.validateUser()
                }
            }
        }
    }

    private fun validateUser() {
        if (edtEmail.text.toString().equals("test") && edtPassword.text.toString().equals("test")) {
            this.goToMain()
        } else {
            Log.d(TAG, "Login attempt unsuccessful *******************")
        }
    }

    private fun goToMain() {
        val mainIntent = Intent(this, MainActivity::class.java)
        startActivity(mainIntent)

        //doesn't allow user to go back to the sign in activity with back button after signing in
        this@SignInActivity.finishAffinity()
    }

    private fun goToSignUp() {
        val signUpIntent = Intent(this, SignUpActivity::class.java); //intent used to transition from one entity to another
        startActivity(signUpIntent)
    }
}