package com.example.paypark.utils

import android.text.TextUtils
import android.util.Base64
import android.util.Log
import android.util.Patterns
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

class DataValidations {
    fun validateEmail(email: String) : Boolean {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun encryptPassword(password: String) : String {
        try{
            val md = MessageDigest.getInstance("SHA-256") //get token
            md.update(password.toByteArray()) //each byte must be converted, pass in byte array

            val hashPass = md.digest() //digest byte array according to token

            return Base64.encodeToString(hashPass, Base64.DEFAULT) //convert the hashed pass to string

        }catch(ex: NoSuchAlgorithmException){
            Log.e("Data Validations", ex.localizedMessage)
        }

        return ""
    }
}
//TODO: add errors and data validations for remaining inputs