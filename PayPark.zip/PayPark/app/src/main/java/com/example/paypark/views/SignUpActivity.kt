package com.example.paypark.views

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.DatePicker
import androidx.fragment.app.DialogFragment
import com.example.paypark.R
import com.example.paypark.model.User
import com.example.paypark.utils.DataValidations
import kotlinx.android.synthetic.main.activity_sign_up.*
import java.text.SimpleDateFormat
import java.util.*

class SignUpActivity : AppCompatActivity(), View.OnClickListener {
    var  selectedGender: String = ""
    //lateinit var user: User
    val TAG: String = this@SignUpActivity.toString()

    companion object {
        //will be created when the SignUpActivity instance is created
        //accessible by inner classes
        var user = User()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        this.initializeSpinner()
        selectedGender = resources.getStringArray(R.array.gender_array).get(0)

        spnGender.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedGender = resources.getStringArray(R.array.gender_array).get(2)
            }

            override fun onItemSelected (
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

                selectedGender = resources.getStringArray(R.array.gender_array).get(position)
            }
        }

        btnSignUp.setOnClickListener(this)

        edtExpiryDate.isFocusable = false;

        edtExpiryDate.setOnClickListener(this)

    }

    fun initializeSpinner() {
        val genderAdapter = ArrayAdapter(this,
            android.R.layout.simple_spinner_item,
            resources.getStringArray(R.array.gender_array))

        spnGender.adapter = genderAdapter
    }

    fun initialSetup() {
        edtName.setAutofillHints(View.AUTOFILL_HINT_NAME)
        edtEmail.setAutofillHints(View.AUTOFILL_HINT_EMAIL_ADDRESS)
        edtCardName.setAutofillHints(View.AUTOFILL_HINT_NAME)
        edtPhoneNo.setAutofillHints(View.AUTOFILL_HINT_PHONE)
    }

    override fun onClick(v: View?) {
        if (v != null) {

            //when the id of clicked item matches the id of btnSignup or edtExpiryDate etc.
            //works like a switch, but break not required
            when(v.id) {
                btnSignUp.id -> {
                    //gather data nad create object of user class
                    if (this.validateData()) {
                        this.fetchData()
                        this.goToMain()
                    }
                }
                edtExpiryDate.id -> {
                    //show the fragment for date picker

                    val dpFragment =
                        DatePickerFragment()
                    //tag is used to identify  fragments
                    dpFragment.show(supportFragmentManager, "datepicker")
                }
            }
        }
    }

    fun fetchData() {
        //user = User() no longer needed cause we have companion object

        user.name = edtName.text.toString()
        user.email = edtEmail.text.toString()
        user.phoneNumber = edtPhoneNo.text.toString()
        user.carPlate = edtPlateNo.text.toString()
        user.creditCardNumber = edtCardNumber.text.toString()
        user.nameOnCard = edtCardName.text.toString()
        user.cvv = edtCVV.text.toString().toInt()
        user.gender = selectedGender
        //expiry date

        user.password = DataValidations().encryptPassword(edtPassword.text.toString())

        Log.d(TAG, "email: " + user.email)
        Log.d(TAG, "password: " + edtPassword.text.toString())
        Log.d(TAG, "encrypted password: " + user.password)
        Log.d(TAG, "gender: " + user.gender)
        Log.d(TAG, "cvv: " + user.cvv)
        Log.d(TAG, "expiry: " + user.expiryDate)

        goToMain()
    }

    fun goToMain() {
        //open MainActivity and pass the user object
        val mainIntent = Intent(this, MainActivity::class.java)
        //mainIntent.putExtra("com.example.paypark.EXTRA_EMAIL", user.email)
        mainIntent.putExtra("com.example.paypark.EXTRA_USER",
            user)

        startActivity(mainIntent)

        //remove signupactivity and all lower stack activities from the activity stack
        this@SignUpActivity.finishAffinity()
        //finishAndRemoveTask() <- for removing activity and all its subtasks
        //finish() <- terminates the entire application, not recommended to be used anywhere
    }

    fun validateData() : Boolean {
        if (edtName.text.toString().isEmpty()) {
            edtName.error = "Please enter name"
            return false
        }
        if (edtEmail.text.toString().isEmpty()) {
            edtEmail.error = "Please enter email"
            return false

        } else if (!DataValidations().validateEmail(edtEmail.text.toString())) {
            edtEmail.error = "Please provide valid email address"
            return false
        }

        if (edtPassword.text.toString().isEmpty()) {
            edtPassword.error = getString(R.string.error_empty_password)
            return false
        }

        if (edtConfirmPassword.text.toString().isEmpty()) {
            edtConfirmPassword.error = "Confirm password cannot be empty"
            return false
        }

        if (!edtConfirmPassword.text.toString().equals(edtPassword.text.toString())){
            edtConfirmPassword.error = "Passwords don't match"
            return false
        }

        return true
    }

    class DatePickerFragment : DialogFragment(), DatePickerDialog.OnDateSetListener{
        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            //use the current date as default date for the date picker
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            return DatePickerDialog(this.requireActivity(), this, year, month, day)
            //DatePickerDialog(parent activity, what listener to use (onDateSet within this class),
            //default date
        }

        override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
            //TODO for the operation to be performed on the date selected by the user

            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)
            val expiryDate = calendar.time

            //this@SignUpActivity.user.expiryDate = expiryDate
            user.expiryDate = expiryDate

            Log.d(this.requireActivity().toString(), "Date : " + expiryDate)

            val sdf = SimpleDateFormat("MM/YY")
            this.requireActivity().edtExpiryDate.setText(sdf.format(expiryDate).toString())
        }
    }
}