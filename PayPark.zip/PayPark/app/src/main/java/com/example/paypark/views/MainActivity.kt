package com.example.paypark.views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.paypark.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //receive data from previous activity through Intent

        //obtain the instance of current Intent
        val currentIntent = this.intent

        //val email = currentIntent.extras?.getString("com.example.paypark.EXTRA_EMAIL")

        //returns serialized user object, so we need to cast as user
//        val user = currentIntent.extras?.get("com.example.paypark.EXTRA_USER") as User
//        tvEmail.text = user.email
//        tvPhoneNo.text = user.phoneNumber
//        tvExpiryDate.text = user.cvv.toString()

        //        tvEmail.text = email
    }
}